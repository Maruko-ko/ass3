### Overview 

This project aims to develop models that predict flight prices and delays based on various features such as weather conditions, flight information, and past performance. The project uses Python for data handling, machine learning model building, and evaluation. The models built include Linear Regression, Random Forest Regressor, and Random Forest Classifier to predict flight price and flight delays. 

### Configure Project Environment (Environment Setup) 
#### 1. Configure a conda environment with the following terminal commands: 
```bash
conda create -n myenv python=3.12 
conda activate myenv 
```

#### 2. Install all relevant python libraries: 
```bash
conda install pandas 
conda install matplotlib 
conda install scikit-learn 
conda install seaborn 
```
### Data Processing 
#### 1. Import relevant libraries: 
```py
import pandas as pd
from IPython.display import display
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import LabelEncoder, StandardScaler, OneHotEncoder
from sklearn.linear_model import LinearRegression  
from sklearn.metrics import mean_squared_error, r2_score 
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.compose import ColumnTransformer
from imblearn.over_sampling import SMOTE
```
#### 2. Load the dataset into Python: 
```py
file_path_1 = './raw_data/flight_price.csv'
file_path_2 = './raw_data/weatherAUS.csv'
file_path_3 = './raw_data/otp_time_series_web.csv'

# Read the file into data frame that Python can process
flight_price_df = pd.read_csv(file_path_1)
weather_df = pd.read_csv(file_path_2)
delay_df = pd.read_csv(file_path_3)
```
#### 3. Create a backup of the datasets: 
```py
flight_price_df_copy = flight_price_df.copy()
weather_df_copy = weather_df.copy()
delay_df_copy = delay_df.copy()
```
#### 4. Check the datasets for missing values: 
```py
# This for loop is to check the percentage of missing value which helps in considering features for training models
for col in weather_df.columns:
    missing_data = weather_df[col].isna().sum()
    missing_percent = missing_data/len(weather_df)*100
    print(f"Column {col} has {missing_percent:.2f}% missing values")

# This for loop is to check the percentage of missing value which helps in considering features for training models
for col in flight_price_df.columns:
    missing_data = flight_price_df[col].isna().sum()
    missing_percent = missing_data/len(flight_price_df)*100
    print(f"Column {col} has {missing_percent:.2f}% missing values")

# This for loop is to check the percentage of missing value which helps in considering features for training models
for col in delay_df.columns:
    missing_data = delay_df[col].isna().sum()
    missing_percent = missing_data/len(delay_df)*100
    print(f"Column {col} has {missing_percent:.2f}% missing values")
```
#### 5. Fill all missing values 
```py
# WEATHER
# Filling missing value with mean
numeric_colums = weather_df_copy.select_dtypes(include=[np.number]).columns
weather_df_copy[numeric_colums] = weather_df_copy[numeric_colums].fillna(weather_df_copy[numeric_colums].mean())
# Filling missing fields with mode
categoric_colums = weather_df_copy.select_dtypes(include=[object]).columns
weather_df_copy[categoric_colums] = weather_df_copy[categoric_colums].apply(lambda x: x.fillna(x.mode()[0]))

# FLIGHT_PRICE
# Filling missing value with mean
numeric_colums = flight_price_df_copy.select_dtypes(include=[np.number]).columns
flight_price_df_copy[numeric_colums] = flight_price_df_copy[numeric_colums].fillna(flight_price_df_copy[numeric_colums].mean())
# Filling missing fields with mode
categoric_colums = flight_price_df_copy.select_dtypes(include=[object]).columns
flight_price_df_copy[categoric_colums] = flight_price_df_copy[categoric_colums].apply(lambda x: x.fillna(x.mode()[0]))

# DELAY
# Fill numerical columns with median values
numeric_colums = delay_df_copy.select_dtypes(include=[np.number]).columns
delay_df_copy[numeric_colums] = delay_df_copy[numeric_colums].fillna(delay_df_copy[numeric_colums].mean())
# Fill categorical columns with mode
categoric_colums = delay_df_copy.select_dtypes(include=[object]).columns
delay_df_copy[categoric_colums] = delay_df_copy[categoric_colums].apply(lambda x: x.fillna(x.mode()[0]))
```

#### 6. Drop the unneeded columns in dataset which include more than 10% missing value
```py
flight_price_df_copy = flight_price_df_copy.drop(columns=[col for col in flight_price_df_copy.columns if 'Unnamed' in col])
print(flight_price_df_copy)

weather_df_copy = weather_df_copy.drop(columns=['Evaporation', 'Sunshine', 'Cloud9am', 'Cloud3pm'])
print(weather_df_copy)

delay_df_copy = delay_df_copy.drop(columns=['Airline'])
```

#### 7. Data transforming
```py
# Appending Date column in flight_price_df_copy to prepare for merging data (as there are only Month and Year in the dataset)
flight_price_df_copy['Date'] = pd.to_datetime(flight_price_df_copy['Year'].astype(str) + '-' + flight_price_df_copy['Month'].astype(str) + '-01')
weather_df_copy['Date'] = pd.to_datetime(weather_df_copy['Date'])
# Standardise data  
weather_df_copy['Location'] = weather_df_copy['Location'].replace('PerthAirport', 'Perth')
```
#### 8. Joining an dmerging data
```py
# We merge the flight_price file with the weatherAUS file
merged_df = pd.merge(
    flight_price_df_copy, 
    weather_df_copy, 
    left_on=['Date', 'Port1'], 
    right_on=['Date', 'Location'], 
    how='inner'
)
print(merged_df.head())
# We merge the above merged file with the delay file
merged_df = pd.merge(
    merged_df, 
    delay_df, 
    left_on=['Year', 'Month', 'Port1', 'Port2'], 
    right_on=['Year', 'Month_Num', 'Departing_Port', 'Arriving_Port'], 
    how='inner'
)
```

#### 8. Dealing with outliers
```py
# Calculate Q1, Q3, and IQR
Q1 = merged_df['$Real'].quantile(0.25)
Q3 = merged_df['$Real'].quantile(0.75)
IQR = Q3 - Q1

lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

print(f"Lower threshold value: {lower_bound}")
print(f"Upper threshold value: {upper_bound}")

# Check for outliers
outliers = merged_df[(merged_df['$Real'] < lower_bound) | (merged_df['$Real'] > upper_bound)]
print(f"Number of outliers before removal: {len(outliers)}")

# Filter and remove outliers
df_cleaned = merged_df[merged_df['$Real'] < upper_bound]  # Keep only values below the upper threshold
print(f"Total number of records initially: {len(merged_df)}")
print(f"Total number of records after removing outliers: {len(df_cleaned)}")

# Check the number of outliers in df_cleaned
outliers_after_cleaning = df_cleaned[(df_cleaned['$Real'] < lower_bound) | (df_cleaned['$Real'] > upper_bound)]
num_outliers_after_cleaning = len(outliers_after_cleaning)

print(f"Number of outliers in df_cleaned: {num_outliers_after_cleaning}")
```

#### 9. Save clean data for further processing
```py
merged_df.to_csv('merged_data.csv', index=False)
```

#### 10. Feature scaling and Feature engineering
```py
# It is used to convert categorical variables into a numerical format that machine learning algorithms can understand
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import LabelEncoder, StandardScaler

# Categorical columns
categorical_cols = ['Port1', 'Port2', 'Departing_Port', 'Arriving_Port']
# Numerical columns
numeric_cols = ['MinTemp', 'MaxTemp', 'WindGustSpeed', '$Value']
# Select features for modeling
X = merged_df[['Port1', 'Port2', 'MinTemp', 'MaxTemp', 'WindGustSpeed', '$Value', 'Departing_Port', 'Arriving_Port']]
# Select target for modeling - $Real - Released flight price on the website
y = merged_df['$Real'] 

ct = ColumnTransformer(
    transformers=[
        ('encode', OneHotEncoder(), categorical_cols),  # Encode categorical columns
        ('scale', StandardScaler(), numeric_cols)  # Scale numerical columns
    ]
)
```
### Splitting data
```py
from sklearn.model_selection import train_test_split
np.random.seed(42)
# Apply ColumnTransformer to encode and scale the data
X_processed = ct.fit_transform(X)
# Split the dataset into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X_processed, y, test_size=0.2, random_state=42)
```

### Training model
#### 1. Linear regression - Additional model
```py
# Create and train the linear regression model
# Import LinearRegression
from sklearn.linear_model import LinearRegression  
# Import the metrics used for evaluation
from sklearn.metrics import mean_squared_error, r2_score 
lin_reg = LinearRegression()
lin_reg.fit(X_train, y_train)

# Make predictions on the test set
y_pred = lin_reg.predict(X_test)

# Evaluate the model
mse_test = mean_squared_error(y_test, y_pred)
r2_test = r2_score(y_test, y_pred)

# Print evaluation results
print(f"Test MSE: {mse_test}")
print(f"Test R-squared: {r2_test}")

```

#### 2. Random Forest Regressor
```py
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score

# Create the Random Forest Regressor model
rf_model = RandomForestRegressor(n_estimators=100, random_state=42)

# Train the model
rf_model.fit(X_train, y_train)

# Predict values on the test set
y_pred = rf_model.predict(X_test)

# Calculate MSE and R-squared
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"Random Forest Test MSE: {mse}")
print(f"Random Forest Test R-squared: {r2}")

```
#### 3. Random Forest Classifier
```py
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.compose import ColumnTransformer
from imblearn.over_sampling import SMOTE
import pandas as pd

# Select features for the model and target variable as we use it for different purpose so different features are selected
X = merged_df[['MinTemp', 'MaxTemp', 'WindGustSpeed', 'Port1', 'Port2', 'Airline']]
y = (merged_df['Departures_Delayed'] > 0).astype(int)  # 1 if the flight was delayed, 0 otherwise

# Step 2: Preprocessing
# One-Hot Encoding for categorical columns and Standardization for numerical columns
categorical_cols = X.select_dtypes(include=['object']).columns

ct = ColumnTransformer(
    transformers=[
        ('onehot', OneHotEncoder(handle_unknown='ignore'), categorical_cols)
    ],
    remainder='passthrough'
)

X_processed = ct.fit_transform(X)

# Standardize the data
scaler = StandardScaler(with_mean=False)
X_scaled = scaler.fit_transform(X_processed)

# Step 3: Handle Imbalance using SMOTE
smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X_scaled, y)

# Step 4: Split the dataset into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X_resampled, y_resampled, test_size=0.2, random_state=42)

# Step 5: Train the Random Forest Classifier
rf_classifier = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced')
rf_classifier.fit(X_train, y_train)

# Step 6: Predict on the test set
y_pred = rf_classifier.predict(X_test)

# Step 7: Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy}")
print("Classification Report:")
print(classification_report(y_test, y_pred))

# Display Confusion Matrix
conf_matrix = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:")
print(conf_matrix)

```

### How to use the trained model
#### 1. Linear regression - Predicting flight price
```py
# Prepare new input data
new_data_dict = {
    'Port1': ['Sydney'],          # Categorical feature
    'Port2': ['Melbourne'],       # Categorical feature
    'MinTemp': [15.0],            # Numerical feature
    'MaxTemp': [25.0],            # Numerical feature
    'WindGustSpeed': [45.0],      # Numerical feature
    '$Value': [250.0],            # Numerical feature
    'Departing_Port': ['Sydney'], # Categorical feature
    'Arriving_Port': ['Melbourne'], # Categorical feature
    'Airline': ['Qantas']         # Categorical feature
}

# Convert new data to DataFrame
new_data_df = pd.DataFrame(new_data_dict)

# Preprocess the new data using the same ColumnTransformer as used during training
new_data_processed = ct.transform(new_data_df)

# Make predictions using the retrained Linear Regression model
new_prediction = lin_reg.predict(new_data_processed)
print(f"Predicted Flight Price: {new_prediction[0]}")
```

#### 2. Trial Random Forest Regressor on Predicting flight price

```py
import pandas as pd

# New data for prediction
new_data_dict = {
    'Port1': ['Sydney'],           # Categorical feature
    'Port2': ['Melbourne'],        # Categorical feature
    'MinTemp': [15.0],             # Numerical feature
    'MaxTemp': [25.0],             # Numerical feature
    'WindGustSpeed': [45.0],       # Numerical feature
    '$Value': [250.0],             # Numerical feature
    'Departing_Port': ['Sydney'],  # Categorical feature
    'Arriving_Port': ['Melbourne'] # Categorical feature
}

# Convert to DataFrame
new_data_df = pd.DataFrame(new_data_dict)
# Transform the new data using the pre-trained ColumnTransformer
new_data_processed = ct.transform(new_data_df)

# Use the trained Random Forest Regressor to make a prediction
if new_data_processed.shape[1] == X_train.shape[1]:
    new_prediction = rf_model.predict(new_data_processed)
    print(f"Predicted Flight Price: {new_prediction[0]}")
else:
    print(f"Feature mismatch between training and new data. Expected {X_train.shape[1]} features but got {new_data_processed.shape[1]} features.")

```
#### 3. Trial Random Forest Classifier on Predicting flight delay
```py
import pandas as pd

# New data for prediction
new_data_dict = {
    'MinTemp': [20.0],            # Numerical feature
    'MaxTemp': [30.0],            # Numerical feature
    'WindGustSpeed': [50.0],      # Numerical feature
    'Port1': ['Sydney'],          # Categorical feature
    'Port2': ['Melbourne'],       # Categorical feature
    'Airline': ['Qantas']         # Categorical feature
}

# Convert to DataFrame
new_data_df = pd.DataFrame(new_data_dict)
# Transform new data using the existing transformer
new_data_processed = ct.transform(new_data_df)
# Use the trained Random Forest Classifier to make a prediction
if new_data_processed.shape[1] == X_train.shape[1]:
    new_prediction = rf_classifier.predict(new_data_processed)
    print(f"Predicted Flight Delay: {'Delayed' if new_prediction[0] == 1 else 'Not Delayed'}")
else:
    print(f"Feature mismatch between training and new data. Expected {X_train.shape[1]} features but got {new_data_processed.shape[1]} features.")

```